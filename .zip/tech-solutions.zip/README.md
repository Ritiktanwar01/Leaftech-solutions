# Tech Solutions Website

A comprehensive website for a tech solutions company with an admin dashboard for content management.

## Features

- Responsive design with black and white theme
- Dynamic content management through admin dashboard
- Authentication system for admin access
- Project portfolio showcase
- Contact form with enquiry management
- About page with company information, values, and team members
- Redux state management
- MongoDB database integration

## Tech Stack

### Frontend
- Next.js 14 (App Router)
- TypeScript
- Tailwind CSS
- Framer Motion for animations
- Lucide React for icons
- shadcn/ui components
- Redux Toolkit for state management

### Backend
- Node.js
- Express.js
- MongoDB with Mongoose
- JWT for authentication
- bcrypt for password hashing

## Getting Started

### Prerequisites
- Node.js (v18 or higher)
- MongoDB (local or Atlas)

### Environment Variables

Create a `.env` file in the root directory with the following variables:

\`\`\`
# Frontend
NEXT_PUBLIC_API_URL=http://localhost:5000

# Backend
PORT=5000
MONGODB_URI=mongodb://localhost:27017/techsolutions
JWT_SECRET=your_jwt_secret_key
JWT_EXPIRES_IN=7d
NODE_ENV=development
FRONTEND_URL=http://localhost:3000
\`\`\`

### Installation

1. Clone the repository
\`\`\`bash
git clone https://github.com/yourusername/tech-solutions.git
cd tech-solutions
\`\`\`

2. Install frontend dependencies
\`\`\`bash
npm install
\`\`\`

3. Install backend dependencies
\`\`\`bash
cd backend
npm install
\`\`\`

4. Seed the database
\`\`\`bash
cd backend
npm run seed
\`\`\`

5. Start the backend server
\`\`\`bash
cd backend
npm run dev
\`\`\`

6. Start the frontend development server
\`\`\`bash
# From the root directory
npm run dev
\`\`\`

7. Access the website at `http://localhost:3000`

### Admin Access

After seeding the database, you can log in to the admin dashboard with the following credentials:

- Email: admin@example.com
- Password: admin123

## Project Structure

\`\`\`
├── app/                    # Next.js app directory
│   ├── (admin)/            # Admin route group
│   │   └── admin/          # Admin pages
│   ├── about/              # About page
│   ├── contact/            # Contact page
│   ├── projects/           # Projects page
│   ├── services/           # Services page
│   ├── layout.tsx          # Root layout
│   └── page.tsx            # Home page
├── components/             # React components
│   ├── admin/              # Admin-specific components
│   └── ui/                 # UI components (shadcn)
├── lib/                    # Utility functions and libraries
│   └── redux/              # Redux store and slices
├── public/                 # Static assets
├── backend/                # Node.js backend
│   ├── models/             # Mongoose models
│   ├── routes/             # Express routes
│   ├── middleware/         # Express middleware
│   ├── seeds/              # Database seed scripts
│   └── server.js           # Express server
└── .env                    # Environment variables
\`\`\`

## Deployment

### Frontend
The frontend can be deployed to Vercel:

1. Push your code to a GitHub repository
2. Import the project in Vercel
3. Set the environment variables
4. Deploy

### Backend
The backend can be deployed to services like Heroku, Railway, or Render:

1. Push your code to a GitHub repository
2. Connect your repository to the deployment platform
3. Set the environment variables
4. Deploy

## License
MIT
