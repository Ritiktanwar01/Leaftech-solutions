const mongoose = require("mongoose")
const bcrypt = require("bcryptjs")
const dotenv = require("dotenv")
const User = require("../models/User")
const Project = require("../models/Project")
const About = require("../models/About")
const Contact = require("../models/Contact")
const Enquiry = require("../models/Enquiry")

// Load environment variables
dotenv.config()

// Connect to MongoDB
mongoose
  .connect(process.env.MONGODB_URI)
  .then(() => console.log("Connected to MongoDB"))
  .catch((err) => {
    console.error("MongoDB connection error:", err)
    process.exit(1)
  })

// Seed data
const seedDatabase = async () => {
  try {
    // Clear existing data
    await User.deleteMany()
    await Project.deleteMany()
    await About.deleteMany()
    await Contact.deleteMany()
    await Enquiry.deleteMany()

    console.log("Data cleared")

    // Create admin user
    const adminPassword = "admin123"
    const salt = await bcrypt.genSalt(10)
    const hashedPassword = await bcrypt.hash(adminPassword, salt)

    await User.create({
      name: "Admin User",
      email: "admin@example.com",
      password: hashedPassword,
      role: "admin",
    })

    console.log("Admin user created")

    // Create projects
    const projects = [
      {
        title: "E-Commerce Platform",
        category: "Web Development",
        description:
          "A fully-featured e-commerce platform with inventory management, payment processing, and customer analytics.",
        image: "/placeholder.svg?height=400&width=600",
        featured: true,
      },
      {
        title: "Healthcare CRM",
        category: "Custom CRM",
        description:
          "A specialized CRM system for healthcare providers to manage patient relationships and streamline operations.",
        image: "/placeholder.svg?height=400&width=600",
        featured: true,
      },
      {
        title: "Logistics Mobile App",
        category: "Mobile Application",
        description:
          "A mobile application for a logistics company to track deliveries, manage fleet, and optimize routes.",
        image: "/placeholder.svg?height=400&width=600",
        featured: true,
      },
      {
        title: "Financial Dashboard",
        category: "Web Application",
        description: "An interactive dashboard for financial analysis with real-time data visualization and reporting.",
        image: "/placeholder.svg?height=400&width=600",
        featured: false,
      },
      {
        title: "Restaurant Management System",
        category: "Custom Software",
        description:
          "A comprehensive system for restaurant management, including inventory, orders, and customer management.",
        image: "/placeholder.svg?height=400&width=600",
        featured: false,
      },
    ]

    await Project.insertMany(projects)
    console.log("Projects created")

    // Create about content
    const about = {
      title: "About TechSolutions",
      subtitle:
        "We're a team of passionate technologists dedicated to helping businesses transform through innovative digital solutions.",
      story:
        "Founded in 2013, TechSolutions began with a simple mission: to help businesses leverage technology to achieve their goals. What started as a small team of three developers has grown into a full-service technology company with expertise across web development, mobile applications, custom software, and IT consulting.",
      mission:
        "Our mission is to empower businesses with innovative technology solutions that drive growth, efficiency, and competitive advantage.",
      vision:
        "We envision a world where every business, regardless of size, can harness the power of technology to reach its full potential.",
      values: [
        {
          title: "Excellence",
          description:
            "We're committed to delivering the highest quality solutions that exceed our clients' expectations.",
          icon: "shield",
        },
        {
          title: "Innovation",
          description:
            "We constantly explore new technologies and approaches to solve complex problems in creative ways.",
          icon: "lightbulb",
        },
        {
          title: "Collaboration",
          description:
            "We work closely with our clients, treating their challenges as our own and building lasting partnerships.",
          icon: "users",
        },
        {
          title: "Integrity",
          description: "We operate with transparency, honesty, and ethical standards in all our interactions.",
          icon: "check-circle",
        },
      ],
      team: [
        {
          name: "John Smith",
          position: "CEO & Founder",
          bio: "15+ years of experience in software development and business leadership.",
          image: "/placeholder.svg?height=200&width=200",
        },
        {
          name: "Sarah Johnson",
          position: "CTO",
          bio: "Expert in cloud architecture and emerging technologies with 12+ years of experience.",
          image: "/placeholder.svg?height=200&width=200",
        },
        {
          name: "Michael Chen",
          position: "COO",
          bio: "Specializes in operations and project management with 10+ years in the tech industry.",
          image: "/placeholder.svg?height=200&width=200",
        },
      ],
    }

    await About.create(about)
    console.log("About content created")

    // Create contact information
    const contact = {
      address: {
        street: "123 Tech Street",
        city: "Innovation City",
        state: "TC",
        zip: "12345",
        country: "United States",
      },
      phone: {
        main: "+1 (555) 123-4567",
        support: "+1 (555) 987-6543",
      },
      email: {
        general: "info@techsolutions.com",
        support: "support@techsolutions.com",
        careers: "careers@techsolutions.com",
      },
      hours: "Monday-Friday, 9am-6pm EST",
      mapEmbed:
        '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3022.215573036935!2d-73.98784492426385!3d40.75797623440235!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25855c6480299%3A0x55194ec5a1ae072e!2sTimes%20Square!5e0!3m2!1sen!2sus!4v1701123456789!5m2!1sen!2sus" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>',
      socialLinks: [
        {
          platform: "facebook",
          url: "https://facebook.com/techsolutions",
        },
        {
          platform: "twitter",
          url: "https://twitter.com/techsolutions",
        },
        {
          platform: "linkedin",
          url: "https://linkedin.com/company/techsolutions",
        },
        {
          platform: "instagram",
          url: "https://instagram.com/techsolutions",
        },
      ],
    }

    await Contact.create(contact)
    console.log("Contact information created")

    // Create sample enquiries
    const enquiries = [
      {
        name: "John Smith",
        email: "john.smith@example.com",
        subject: "Website Development Inquiry",
        message:
          "I'm interested in developing a new website for my business. Could you provide more information about your web development services and pricing?",
        service: "Web Development",
        status: "completed",
        createdAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000), // 10 days ago
      },
      {
        name: "Sarah Johnson",
        email: "sarah.j@example.com",
        subject: "Mobile App Development",
        message:
          "We're looking to develop a mobile app for our retail business. I'd like to schedule a consultation to discuss our requirements.",
        service: "Mobile Application",
        status: "in-progress",
        createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000), // 5 days ago
      },
      {
        name: "Michael Chen",
        email: "m.chen@example.com",
        subject: "Custom CRM Solution",
        message:
          "Our company needs a custom CRM solution to better manage our customer relationships. Can you help us with this?",
        service: "Custom CRM",
        status: "new",
        createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), // 2 days ago
      },
      {
        name: "Emily Davis",
        email: "emily.d@example.com",
        subject: "IT Consulting Services",
        message:
          "I'm looking for IT consulting services to help optimize our current technology infrastructure. What services do you offer in this area?",
        service: "IT Consulting",
        status: "new",
        createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000), // 1 day ago
      },
      {
        name: "Robert Wilson",
        email: "r.wilson@example.com",
        subject: "Cloud Solutions",
        message:
          "We're considering moving our infrastructure to the cloud. Can you provide information about your cloud migration services?",
        service: "Cloud Solutions",
        status: "new",
        createdAt: new Date(), // Today
      },
    ]

    await Enquiry.insertMany(enquiries)
    console.log("Sample enquiries created")

    console.log("Database seeded successfully")
    process.exit(0)
  } catch (error) {
    console.error("Error seeding database:", error)
    process.exit(1)
  }
}

seedDatabase()
