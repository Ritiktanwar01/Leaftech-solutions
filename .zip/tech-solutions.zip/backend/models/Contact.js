const mongoose = require("mongoose")

const socialLinkSchema = new mongoose.Schema({
  platform: {
    type: String,
    required: true,
    trim: true,
  },
  url: {
    type: String,
    required: true,
    trim: true,
  },
})

const contactSchema = new mongoose.Schema(
  {
    address: {
      street: {
        type: String,
        required: true,
        trim: true,
      },
      city: {
        type: String,
        required: true,
        trim: true,
      },
      state: {
        type: String,
        required: true,
        trim: true,
      },
      zip: {
        type: String,
        required: true,
        trim: true,
      },
      country: {
        type: String,
        required: true,
        trim: true,
      },
    },
    phone: {
      main: {
        type: String,
        required: true,
        trim: true,
      },
      support: {
        type: String,
        required: true,
        trim: true,
      },
    },
    email: {
      general: {
        type: String,
        required: true,
        trim: true,
        lowercase: true,
      },
      support: {
        type: String,
        required: true,
        trim: true,
        lowercase: true,
      },
      careers: {
        type: String,
        required: true,
        trim: true,
        lowercase: true,
      },
    },
    hours: {
      type: String,
      required: true,
      trim: true,
    },
    mapEmbed: {
      type: String,
      required: true,
    },
    socialLinks: [socialLinkSchema],
  },
  {
    timestamps: true,
  },
)

const Contact = mongoose.model("Contact", contactSchema)

module.exports = Contact
