const express = require("express")
const router = express.Router()
const Enquiry = require("../models/Enquiry")
const { protect, authorize } = require("../middleware/auth")

// @route   GET /api/enquiries
// @desc    Get all enquiries (admin only)
// @access  Private/Admin
router.get("/", protect, authorize("admin"), async (req, res) => {
  try {
    const enquiries = await Enquiry.find().sort({ createdAt: -1 })
    res.json(enquiries)
  } catch (error) {
    res.status(500).json({ message: error.message })
  }
})

module.exports = router
