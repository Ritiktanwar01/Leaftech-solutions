const express = require("express")
const router = express.Router()
const About = require("../models/About")

// @route   GET /api/about
// @desc    Get about page content
// @access  Public
router.get("/", async (req, res) => {
  try {
    // Get the most recent about content
    const about = await About.findOne().sort({ createdAt: -1 })

    if (!about) {
      return res.status(404).json({ message: "About content not found" })
    }

    res.json(about)
  } catch (error) {
    res.status(500).json({ message: error.message })
  }
})

module.exports = router
