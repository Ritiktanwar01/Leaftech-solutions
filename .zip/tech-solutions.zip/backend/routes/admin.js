const express = require("express")
const router = express.Router()
const Project = require("../models/Project")
const About = require("../models/About")
const Contact = require("../models/Contact")
const Enquiry = require("../models/Enquiry")
const { protect, authorize } = require("../middleware/auth")

// Protect all admin routes
router.use(protect)
router.use(authorize("admin"))

// @route   GET /api/admin/dashboard
// @desc    Get dashboard statistics
// @access  Private/Admin
router.get("/dashboard", async (req, res) => {
  try {
    // Get visitor count (this would typically come from an analytics service)
    // For demo purposes, we'll generate random data
    const visitorData = []
    const today = new Date()
    for (let i = 29; i >= 0; i--) {
      const date = new Date(today)
      date.setDate(date.getDate() - i)
      visitorData.push({
        date: date.toISOString().split("T")[0],
        count: Math.floor(Math.random() * 500) + 100,
      })
    }

    const totalVisitors = visitorData.reduce((sum, day) => sum + day.count, 0)
    const lastMonthVisitors = Math.floor(totalVisitors * 0.8) // Simulating previous month data

    // Get enquiry statistics
    const totalEnquiries = await Enquiry.countDocuments()
    const lastMonthEnquiries = await Enquiry.countDocuments({
      createdAt: { $lt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) },
    })

    // Get enquiry types distribution
    const enquiryTypes = [
      { label: "Web Dev", value: 35, color: "#000000" },
      { label: "Mobile Apps", value: 25, color: "#374151" },
      { label: "CRM", value: 20, color: "#6b7280" },
      { label: "Other", value: 20, color: "#9ca3af" },
    ]

    // Get project statistics
    const totalProjects = await Project.countDocuments()
    const lastMonthProjects = await Project.countDocuments({
      createdAt: { $lt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) },
    })

    // Calculate conversion rate
    const conversionRate = ((totalEnquiries / totalVisitors) * 100).toFixed(1)
    const lastMonthConversionRate = ((lastMonthEnquiries / lastMonthVisitors) * 100).toFixed(1)

    res.json({
      visitors: {
        total: totalVisitors,
        change: `+${Math.floor(((totalVisitors - lastMonthVisitors) / lastMonthVisitors) * 100)}%`,
      },
      enquiries: {
        total: totalEnquiries,
        change: `+${Math.floor(((totalEnquiries - lastMonthEnquiries) / lastMonthEnquiries) * 100)}%`,
      },
      projects: {
        total: totalProjects,
        change: `+${Math.floor(((totalProjects - lastMonthProjects) / lastMonthProjects) * 100)}%`,
      },
      conversionRate: {
        rate: Number.parseFloat(conversionRate),
        change: `+${(Number.parseFloat(conversionRate) - Number.parseFloat(lastMonthConversionRate)).toFixed(1)}%`,
      },
      visitorData,
      enquiryTypes,
    })
  } catch (error) {
    res.status(500).json({ message: error.message })
  }
})

// @route   GET /api/admin/enquiries
// @desc    Get all enquiries
// @access  Private/Admin
router.get("/enquiries", async (req, res) => {
  try {
    const enquiries = await Enquiry.find().sort({ createdAt: -1 })
    res.json(enquiries)
  } catch (error) {
    res.status(500).json({ message: error.message })
  }
})

// @route   PATCH /api/admin/enquiries/:id/status
// @desc    Update enquiry status
// @access  Private/Admin
router.patch("/enquiries/:id/status", async (req, res) => {
  try {
    const { status } = req.body

    if (!["new", "in-progress", "completed", "spam"].includes(status)) {
      return res.status(400).json({ message: "Invalid status" })
    }

    const enquiry = await Enquiry.findByIdAndUpdate(req.params.id, { status }, { new: true, runValidators: true })

    if (!enquiry) {
      return res.status(404).json({ message: "Enquiry not found" })
    }

    res.json(enquiry)
  } catch (error) {
    res.status(500).json({ message: error.message })
  }
})

// @route   PATCH /api/admin/enquiries/:id/notes
// @desc    Update enquiry notes
// @access  Private/Admin
router.patch("/enquiries/:id/notes", async (req, res) => {
  try {
    const { notes } = req.body

    const enquiry = await Enquiry.findByIdAndUpdate(req.params.id, { notes }, { new: true, runValidators: true })

    if (!enquiry) {
      return res.status(404).json({ message: "Enquiry not found" })
    }

    res.json(enquiry)
  } catch (error) {
    res.status(500).json({ message: error.message })
  }
})

// @route   POST /api/admin/projects
// @desc    Create a new project
// @access  Private/Admin
router.post("/projects", async (req, res) => {
  try {
    const { title, category, description, image, featured } = req.body

    const project = await Project.create({
      title,
      category,
      description,
      image,
      featured,
    })

    res.status(201).json(project)
  } catch (error) {
    res.status(500).json({ message: error.message })
  }
})

// @route   PUT /api/admin/projects/:id
// @desc    Update a project
// @access  Private/Admin
router.put("/projects/:id", async (req, res) => {
  try {
    const { title, category, description, image, featured } = req.body

    const project = await Project.findByIdAndUpdate(
      req.params.id,
      { title, category, description, image, featured },
      { new: true, runValidators: true },
    )

    if (!project) {
      return res.status(404).json({ message: "Project not found" })
    }

    res.json(project)
  } catch (error) {
    res.status(500).json({ message: error.message })
  }
})

// @route   DELETE /api/admin/projects/:id
// @desc    Delete a project
// @access  Private/Admin
router.delete("/projects/:id", async (req, res) => {
  try {
    const project = await Project.findByIdAndDelete(req.params.id)

    if (!project) {
      return res.status(404).json({ message: "Project not found" })
    }

    res.json({ message: "Project removed" })
  } catch (error) {
    res.status(500).json({ message: error.message })
  }
})

// @route   PUT /api/admin/about
// @desc    Update about page content
// @access  Private/Admin
router.put("/about", async (req, res) => {
  try {
    const { title, subtitle, story, mission, vision, values, team } = req.body

    // Find the most recent about content
    let about = await About.findOne().sort({ createdAt: -1 })

    if (about) {
      // Update existing content
      about = await About.findByIdAndUpdate(
        about._id,
        { title, subtitle, story, mission, vision, values, team },
        { new: true, runValidators: true },
      )
    } else {
      // Create new content if none exists
      about = await About.create({
        title,
        subtitle,
        story,
        mission,
        vision,
        values,
        team,
      })
    }

    res.json(about)
  } catch (error) {
    res.status(500).json({ message: error.message })
  }
})

// @route   PUT /api/admin/contact
// @desc    Update contact information
// @access  Private/Admin
router.put("/contact", async (req, res) => {
  try {
    const { address, phone, email, hours, mapEmbed, socialLinks } = req.body

    // Find the most recent contact information
    let contact = await Contact.findOne().sort({ createdAt: -1 })

    if (contact) {
      // Update existing information
      contact = await Contact.findByIdAndUpdate(
        contact._id,
        { address, phone, email, hours, mapEmbed, socialLinks },
        { new: true, runValidators: true },
      )
    } else {
      // Create new information if none exists
      contact = await Contact.create({
        address,
        phone,
        email,
        hours,
        mapEmbed,
        socialLinks,
      })
    }

    res.json(contact)
  } catch (error) {
    res.status(500).json({ message: error.message })
  }
})

module.exports = router
