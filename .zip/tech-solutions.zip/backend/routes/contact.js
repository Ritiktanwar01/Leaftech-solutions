const express = require("express")
const router = express.Router()
const Contact = require("../models/Contact")
const Enquiry = require("../models/Enquiry")

// @route   GET /api/contact
// @desc    Get contact information
// @access  Public
router.get("/", async (req, res) => {
  try {
    // Get the most recent contact information
    const contact = await Contact.findOne().sort({ createdAt: -1 })

    if (!contact) {
      return res.status(404).json({ message: "Contact information not found" })
    }

    res.json(contact)
  } catch (error) {
    res.status(500).json({ message: error.message })
  }
})

// @route   POST /api/contact/enquiry
// @desc    Submit a contact form enquiry
// @access  Public
router.post("/enquiry", async (req, res) => {
  try {
    const { name, email, subject, message, service } = req.body

    // Create new enquiry
    const enquiry = await Enquiry.create({
      name,
      email,
      subject,
      message,
      service,
    })

    res.status(201).json({ message: "Enquiry submitted successfully", enquiry })
  } catch (error) {
    res.status(500).json({ message: error.message })
  }
})

module.exports = router
